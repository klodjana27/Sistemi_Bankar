using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using SistemiBankar.Data;
using SistemiBankar.Models;
using System.Linq;
using System.Threading.Tasks;

namespace SistemiBankar.Controllers
{
    [Authorize]
    public class AccountsController : Controller
    {
        private readonly BankContext _context;
        private readonly UserManager<Customer> _userManager;

        public AccountsController(BankContext context, UserManager<Customer> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // Metodat e kontrollerit për menaxhimin e llogarive dhe transaksioneve
    }
}
