using Microsoft.EntityFrameworkCore;
using SistemiBankar.Models; // Importimi i modeleve të përdorura

namespace SistemiBankar.Data
{
    public class BankContext : DbContext
    {
        public BankContext(DbContextOptions<BankContext> options) : base(options)
        {
        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Account> Accounts { get; set; }
        public DbSet<Transaction> Transactions { get; set; }

        // Mund të shtoni konfigurime shtesë të bazës së të dhënave sipas nevojës
    }
}
