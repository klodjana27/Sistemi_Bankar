using SistemiBankar.Data;


public class Customer
{
    public int Id { get; set; }
    public string UserName { get; set; }
    public string Password { get; set; } // For simplicity, use secure password hashing in real applications
    public List<Account> Accounts { get; set; }
}
